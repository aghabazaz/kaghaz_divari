<?php

$lang = array (
    'dashboard' => 'داشبورد'
    
) ;
