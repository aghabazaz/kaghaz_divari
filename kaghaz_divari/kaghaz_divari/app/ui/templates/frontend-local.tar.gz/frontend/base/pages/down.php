<style>
    .bg
    {
       background: rgba(169,3,41,1);
        background: -moz-linear-gradient(top, rgba(169,3,41,1) 0%, rgba(143,2,34,1) 62%, rgba(109,0,25,1) 100%);
        background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(169,3,41,1)), color-stop(62%, rgba(143,2,34,1)), color-stop(100%, rgba(109,0,25,1)));
        background: -webkit-linear-gradient(top, rgba(169,3,41,1) 0%, rgba(143,2,34,1) 62%, rgba(109,0,25,1) 100%);
        background: -o-linear-gradient(top, rgba(169,3,41,1) 0%, rgba(143,2,34,1) 62%, rgba(109,0,25,1) 100%);
        background: -ms-linear-gradient(top, rgba(169,3,41,1) 0%, rgba(143,2,34,1) 62%, rgba(109,0,25,1) 100%);
        background: linear-gradient(to bottom, rgba(169,3,41,1) 0%, rgba(143,2,34,1) 62%, rgba(109,0,25,1) 100%);
        filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#a90329', endColorstr='#6d0019', GradientType=0 );
        color:white;
        font-size:120px;
        text-align:center;
        height:100%;
        width:100%;
       margin: 0px;
        min-height: 100%; 
        
    }
</style>
<?
$title="وب سایت غیرفعال است";
?>
<?php include 'parts' . \f\DS . 'header_2.php' ; ?>
<div style="display: table; height: 100%; vertical-align: middle; text-align: center; width: 100%;">
  <div style="display: table-cell; vertical-align: middle;">
    Website Is Down.... :(
  </div>
    
</div>
    <?php
    include 'parts' . \f\DS . 'footer_2.php' ;
    