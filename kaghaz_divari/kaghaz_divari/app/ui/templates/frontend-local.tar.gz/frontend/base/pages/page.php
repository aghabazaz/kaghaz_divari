<?php include 'parts' . \f\DS . 'header.php' ; ?>

<div style="height: 200px; background-color: lightpink">
    Default template page   
</div>

<div style="background-color: lightblue; height: 200px;">
    <?= $content ?>
</div>

<?php
include 'parts' . \f\DS . 'footer.php' ;
