<script src="<?= \f\ifm::app ()->siteUrl ?>app/ui/templates/frontend/main/pages/js/jquery.easing.1.3.js" type="text/javascript"></script>
<script src="<?= \f\ifm::app ()->siteUrl ?>app/ui/templates/frontend/main/pages/js/tms_presets.js" type="text/javascript"></script>
<script src="<?= \f\ifm::app ()->siteUrl ?>app/ui/templates/frontend/main/pages/js/tms-0.3.js" type="text/javascript"></script>

<script type="text/javascript">

</script>